-- แก้ไขตาราง orders เพื่อเพิ่มฟิลด์ใหม่
ALTER TABLE orders
ADD COLUMN player_uid VARCHAR(100) NOT NULL AFTER id,
ADD COLUMN server_name VARCHAR(100) NULL AFTER player_uid,
ADD COLUMN game_id BIGINT(20) NULL AFTER server_name,
ADD COLUMN product_id BIGINT(20) NULL AFTER id,
ADD COLUMN quantity INT NOT NULL DEFAULT 1 AFTER product_id,
ADD COLUMN unit_price DECIMAL(10, 2) NULL AFTER quantity;

-- เพิ่ม foreign key สำหรับ product_id และ game_id
ALTER TABLE orders
ADD FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
ADD FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE SET NULL;

-- เพิ่ม index สำหรับ player_uid และ server_name
ALTER TABLE orders
ADD INDEX idx_player_uid (player_uid),
ADD INDEX idx_server_name (server_name);

USE game_topup;