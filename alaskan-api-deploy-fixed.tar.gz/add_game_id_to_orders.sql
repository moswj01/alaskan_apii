-- เพิ่ม game_id column ให้ orders table
USE game_topup;

-- เพิ่ม game_id column
ALTER TABLE orders 
ADD COLUMN game_id BIGINT(20) NULL AFTER server_name;

-- เพิ่ม foreign key constraint
ALTER TABLE orders 
ADD FOREIGN KEY (game_id) REFERENCES games(id) ON DELETE SET NULL;

-- เพิ่ม index
ALTER TABLE orders 
ADD INDEX idx_game_id (game_id);
