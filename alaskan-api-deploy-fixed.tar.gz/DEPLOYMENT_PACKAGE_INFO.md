# 📦 Alaskan API Deployment Package

## ไฟล์บีบอัด: `alaskan-api-deploy.tar.gz` (23KB)

### 📋 ไฟล์ที่รวมอยู่ใน Package:

#### Core Application Files:
- ✅ `index.js` - Main server file
- ✅ `package.json` - Dependencies และ scripts
- ✅ `package-lock.json` - Exact dependency versions
- ✅ `auth.js` - JWT authentication middleware
- ✅ `dbUtils.js` - Database utility functions
- ✅ `orderRoutes.js` - Order management API
- ✅ `refundRoutes.js` - Refund management API

#### Docker & Deployment:
- ✅ `Dockerfile` - Container configuration
- ✅ `.dockerignore` - Files to exclude from Docker
- ✅ `.env.production` - Production environment variables

#### Database Setup:
- ✅ `add_game_id_to_orders.sql` - Order table updates
- ✅ `alter_orders_table.sql` - Table structure changes
- ✅ `create_refunds_table.sql` - Refund table creation

#### Documentation:
- ✅ `README.md` - Project overview
- ✅ `EASYPANEL_DEPLOY.md` - EasyPanel deployment guide
- ✅ `CORS_FIX_GUIDE.md` - CORS troubleshooting

## 🚀 การใช้งาน Deployment Package:

### 1. Extract Files:
```bash
tar -xzf alaskan-api-deploy.tar.gz
cd alaskan-api/
```

### 2. EasyPanel Deployment:
1. Upload ไฟล์ทั้งหมดไปยัง GitHub/GitLab repository
2. สร้าง App ใหม่ใน EasyPanel
3. เลือก Source: GitHub/GitLab repository
4. ตั้งค่า Environment Variables:

```bash
NODE_ENV=production
PORT=3000
MYSQL_HOST=kkc_alaskan
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=@Alaskan2025
MYSQL_DATABASE=game_topup
JWT_SECRET=Alaskan2025_Super_Secret_JWT_Key_Production
FRONTEND_URL=https://alaskans.store
```

### 3. Manual Upload (Alternative):
```bash
# Extract และ upload ไฟล์ไปยัง server
scp alaskan-api-deploy.tar.gz user@server:/path/to/deployment/
ssh user@server
cd /path/to/deployment/
tar -xzf alaskan-api-deploy.tar.gz
```

### 4. Docker Build:
```bash
docker build -t alaskan-api .
docker run -d --name alaskan-api -p 3000:3000 alaskan-api
```

## 🔧 Database Setup:

หลัง deploy ให้รัน SQL scripts:
```sql
-- 1. Create refunds table
SOURCE create_refunds_table.sql;

-- 2. Update orders table structure  
SOURCE alter_orders_table.sql;

-- 3. Add game_id to orders (if needed)
SOURCE add_game_id_to_orders.sql;
```

## 🧪 Post-Deployment Testing:

```bash
# Health check
curl https://your-domain.com/health

# CORS test
curl -X OPTIONS -H "Origin: https://alaskans.store" \
  https://your-domain.com/api/users

# Login test
curl -X POST -H "Content-Type: application/json" \
  -d '{"email":"admin@alaskan.com","password":"@Alaskan2025"}' \
  https://your-domain.com/login
```

## ⚡ Features Included:

- ✅ **Authentication**: JWT-based user authentication
- ✅ **CORS**: Configured for https://alaskans.store
- ✅ **MySQL Pool**: Stable database connections
- ✅ **Order Management**: Complete CRUD operations
- ✅ **Refund System**: Full refund management
- ✅ **Health Checks**: Built-in monitoring endpoint
- ✅ **Error Handling**: Comprehensive error management
- ✅ **Production Ready**: Optimized for deployment

## 📊 Package Stats:
- **Size**: 23KB compressed
- **Files**: 16 essential files
- **No Dependencies**: node_modules excluded (auto-installed)
- **Documentation**: Complete setup guides included

---

**Ready for deployment! 🚀**

Package contains everything needed for production deployment to EasyPanel or any Docker-compatible platform.