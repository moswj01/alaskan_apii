# 🚨 EasyPanel Deployment Fix Guide

## ปัญหาที่พบ: 502 Error - Service Not Reachable

API ได้รับ CORS error เพราะ service ไม่ได้รันบน EasyPanel ตอนนี้

## ✅ สิ่งที่แก้ไขแล้ว:

### 1. CORS Configuration

```javascript
app.use(
  cors({
    origin: [
      "http://localhost:4200",
      "http://localhost:58238",
      "https://alaskans.store",
      "https://alaskans.com",
      "https://kkc-alaskan-api.ruhy1d.easypanel.host",
    ],
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: [
      "Content-Type",
      "Authorization",
      "Access-Control-Allow-Origin",
    ],
    credentials: true,
    optionsSuccessStatus: 200,
  })
);

// Handle preflight requests explicitly
app.options("*", (req, res) => {
  res.header("Access-Control-Allow-Origin", req.headers.origin || "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.header("Access-Control-Allow-Credentials", "true");
  res.sendStatus(200);
});
```

### 2. Production Environment Variables

```bash
NODE_ENV=production
PORT=3000
MYSQL_HOST=kkc_alaskan
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=@Alaskan2025
MYSQL_DATABASE=game_topup
JWT_SECRET=Alaskan2025_Super_Secret_JWT_Key_Production_EasyPanel
FRONTEND_URL=https://alaskans.store
```

## 🔧 ขั้นตอนการแก้ไขใน EasyPanel:

### 1. ตรวจสอบ App Status

- เข้าไปยัง EasyPanel Dashboard
- ดู status ของ app `kkc-alaskan-api`
- ตรวจสอบว่า container กำลังรันหรือไม่

### 2. ตรวจสอบ Logs

```bash
# ใน EasyPanel Console ดู logs ของ container:
- Container might be failing to start
- MySQL connection errors
- Port binding issues
```

### 3. ตรวจสอบ Environment Variables

ตรวจสอบว่าตั้งค่าครบทุกตัวใน EasyPanel:

```
NODE_ENV=production
PORT=3000
MYSQL_HOST=kkc_alaskan
MYSQL_PORT=3306
MYSQL_USER=root
MYSQL_PASSWORD=@Alaskan2025
MYSQL_DATABASE=game_topup
JWT_SECRET=Alaskan2025_Super_Secret_JWT_Key_Production_EasyPanel
FRONTEND_URL=https://alaskans.store
```

### 4. ตรวจสอบ Port Configuration

- Internal Port: 3000
- External Port: 80/443
- Protocol: HTTP

### 5. Restart/Redeploy

- กด Restart container หรือ Redeploy
- รอให้ build เสร็จและ container เริ่มทำงาน

## 🏗️ การ Deploy ใหม่:

### หากต้องการ deploy ใหม่ทั้งหมด:

1. **Push โค้ดล่าสุดไปยัง GitHub/GitLab**

   ```bash
   git add .
   git commit -m "Fix CORS configuration for production"
   git push origin main
   ```

2. **Redeploy ใน EasyPanel**

   - กด Redeploy button
   - รอให้ Docker build เสร็จ

3. **ตรวจสอบ Health Check**
   ```bash
   curl https://kkc-alaskan-api.ruhy1d.easypanel.host/health
   ```

## 🧪 การทดสอบหลัง Deploy:

### 1. Health Check

```bash
curl https://kkc-alaskan-api.ruhy1d.easypanel.host/health
```

Expected: `{"status":"OK",...}`

### 2. CORS Test

```bash
curl -X OPTIONS \
  -H "Origin: https://alaskans.store" \
  -H "Access-Control-Request-Method: GET" \
  -H "Access-Control-Request-Headers: Content-Type,Authorization" \
  https://kkc-alaskan-api.ruhy1d.easypanel.host/api/users
```

Expected: Status 200 with CORS headers

### 3. API Test

```bash
curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@alaskan.com","password":"@Alaskan2025"}' \
  https://kkc-alaskan-api.ruhy1d.easypanel.host/login
```

Expected: JWT token response

## 🚨 Troubleshooting:

### MySQL Connection Issues:

- ตรวจสอบว่า `kkc_alaskan` host เข้าถึงได้จาก container
- ลอง connect ด้วย mysql client

### Container Won't Start:

- ดู logs ใน EasyPanel console
- ตรวจสอบ Dockerfile syntax
- ตรวจสอบ environment variables

### CORS ยังไม่ทำงาน:

- ตรวจสอบว่า API response มี headers:
  - `Access-Control-Allow-Origin`
  - `Access-Control-Allow-Methods`
  - `Access-Control-Allow-Headers`

---

## 📝 สิ่งที่ต้องทำใน EasyPanel Dashboard:

1. ✅ ตรวจสอบ App Status
2. ✅ ดู Logs เพื่อหา error
3. ✅ ตรวจสอบ Environment Variables
4. ✅ Restart/Redeploy app
5. ✅ Test health check
6. ✅ Test CORS

**การแก้ไข CORS เสร็จแล้ว - ตอนนี้ต้องแก้ปัญหา service ไม่รันใน EasyPanel! 🔧**
